The fedora plugin is deprecated. Use the [dnf plugin](https://github.com/ohmyzsh/ohmyzsh/tree/master/plugins/dnf) instead.

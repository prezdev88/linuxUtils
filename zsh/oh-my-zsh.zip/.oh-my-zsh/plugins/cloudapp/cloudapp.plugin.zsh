print -Pn "%F{yellow}"
print "[oh-my-zsh] The CloudApp API no longer works, so the cloudapp plugin will"
print "[oh-my-zsh] be removed shortly. Please remove it from your plugins list."
print -Pn "%f"
